export default async function handler(req, res) {
  const DUTTYFY_API_URL = 'https://www.links-pagamentos.online/api-pix/Uhufz5e7pZJpgujbwGnlas-Aha0huvf43lXhokQINc_n5MUh5lhc6mu-5R1EpmGhiUBD0qOcKsPerSv4KIzd_g';

  const orderId = req.query.order_id;

  if (!orderId) {
    res.status(400).json({ status: 'error', message: 'order_id obrigatorio' });
    return;
  }

  try {
    const response = await fetch(DUTTYFY_API_URL + '/' + encodeURIComponent(orderId), {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      res.status(200).json({ status: 'pending' });
      return;
    }

    const json = await response.json();
    const data = json.data || json;

    const status = (data.status || '').toLowerCase();

    if (status === 'paid' || status === 'approved' || status === 'confirmed' || status === 'completed') {
      res.status(200).json({ status: 'paid' });
    } else if (status === 'expired' || status === 'cancelled' || status === 'canceled' || status === 'refunded') {
      res.status(200).json({ status: 'expired' });
    } else {
      res.status(200).json({ status: 'pending' });
    }
  } catch (e) {
    res.status(200).json({ status: 'pending' });
  }
}
